package com.springbootlearning.learningspringboot3;

record VideoSearch(String name, String description) {
}
