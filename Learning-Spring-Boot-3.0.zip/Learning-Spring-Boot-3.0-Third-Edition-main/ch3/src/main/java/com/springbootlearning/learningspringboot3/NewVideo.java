package com.springbootlearning.learningspringboot3;

record NewVideo(String name, String description) {
}
