package com.springbootlearning.learningspringboot3;

record UniversalSearch(String value) {
}
