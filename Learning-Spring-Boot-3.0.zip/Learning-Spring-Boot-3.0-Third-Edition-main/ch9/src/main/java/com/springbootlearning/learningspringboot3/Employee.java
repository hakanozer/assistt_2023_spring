package com.springbootlearning.learningspringboot3;

public record Employee(String name, String role) {
}
