package com.springbootlearning.learningspringboot3;

record Video(String name) {
}
