package com.springbootlearning.learningspringboot3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter2ApplicationTests {

  @Test
  void contextLoads() {}

}
