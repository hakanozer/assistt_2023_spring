package com.springbootlearning.learningspringboot3;

/**
 * @see https://developers.google.com/youtube/v3/docs/videos/list
 */
record PageInfo(Integer totalResults, Integer resultsPerPage) {
}
