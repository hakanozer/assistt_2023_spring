package com.springbootlearning.learningspringboot3;

record SearchResult(String kind, String etag, SearchId id, SearchSnippet snippet) {
}
