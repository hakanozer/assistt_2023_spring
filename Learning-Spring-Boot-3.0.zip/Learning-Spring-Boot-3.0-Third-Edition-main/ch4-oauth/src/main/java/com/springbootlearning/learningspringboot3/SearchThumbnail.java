package com.springbootlearning.learningspringboot3;

record SearchThumbnail(String url, Integer width, Integer height) {
}
