package com.springbootlearning.learningspringboot3;

record SearchId(String kind, String videoId, String channelId, String playlistId) {
}
