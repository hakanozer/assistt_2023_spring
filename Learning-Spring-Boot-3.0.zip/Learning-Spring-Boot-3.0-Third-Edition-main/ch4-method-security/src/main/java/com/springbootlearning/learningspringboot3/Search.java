package com.springbootlearning.learningspringboot3;

record Search(String value) {
}
